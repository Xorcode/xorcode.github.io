<?php
require_once 'Zend/Controller/Action.php';
class IndexController extends Zend_Controller_Action
{
    public function indexAction ()
    {
    }

    public function sitemapAction ()
    {
        $this->view->layout()->disableLayout();
        $this->_helper->viewRenderer->setNoRender();
        $sitemap = $this->view->navigation()->sitemap()
            ->setUseXmlDeclaration(true)
            ->setFormatOutput(true)
            ->setUseSitemapValidators(true)
            ->setRole();
        $this->getResponse()->setHeader('Content-Type', 'application/xml')->setBody($sitemap);
    }

    public function robotsAction ()
    {
        $this->view->layout()->disableLayout();
        $this->getResponse()->setHeader('Content-Type', 'text/plain');
    }
}
