<?php
require_once ('Zend/Application/Resource/ResourceAbstract.php');
class Myapp_Application_Resource_View extends Zend_Application_Resource_ResourceAbstract
{
    protected static $_view;

    public function init ()
    {
        return $this->getView();
    }

    public function getView ()
    {
        if (null === self::$_view) {
            self::$_view = new Zend_View($this->getOptions());
            $layout = Zend_Layout::getMvcInstance();
            self::$_view->doctype('HTML5');
            self::$_view->setEncoding('UTF-8');
            self::$_view->addHelperPath('Myapp/View/Helper');
            self::$_view->headTitle('Myapp')
                ->setSeparator(' - ');
            self::$_view->headMeta()
                ->appendHttpEquiv('Content-Type', sprintf('text/html; charset=%s', self::$_view->getEncoding()));
            $viewRenderer = Zend_Controller_Action_HelperBroker::getStaticHelper('ViewRenderer');
            $viewRenderer->setView(self::$_view);
        }
        return self::$_view;
    }
}
